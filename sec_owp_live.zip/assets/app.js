function getParam(name) {
  const m = new URLSearchParams(location.search).get(name);
  return m && decodeURIComponent(m);
}

async function loadData() {
  const source = getParam('source');
  if (source === 'sheet') {
    const sheetUrl = getParam('sheet');
    if (!sheetUrl) {
      alert('Add ?source=sheet&sheet=<published-csv-url>');
      return;
    }
    const resp = await fetch(sheetUrl + '&_=' + Date.now());
    const csv = await resp.text();
    const data = csvToJson(csv);
    render(data, 'Google Sheet');
  } else {
    const resp = await fetch('sec_owp_live.json?_=' + Date.now());
    const data = await resp.json();
    render(data, 'JSON (Auto)');
  }
}

function csvToJson(csv) {
  const lines = csv.trim().split(/?
/);
  const headers = lines[0].split(',').map(h => h.trim());
  const rows = lines.slice(1).map(line => line.split(',').map(c => c.trim()));
  const teams = rows.map(cols => {
    const obj = {};
    headers.forEach((h, i) => obj[h] = cols[i]);
    return {
      team: obj.team,
      sec_record: obj.sec_record,
      owp_current: Number(obj.owp_current),
      owp_proj_chalk: Number(obj.owp_proj_chalk),
      owp_proj_upset: Number(obj.owp_proj_upset)
    };
  });
  return { last_updated: new Date().toISOString(), teams };
}

function render(data, modeLabel) {
  document.getElementById('lastUpdated').textContent =
    `Source: ${modeLabel} • Last updated: ${new Date(data.last_updated).toLocaleString()}`;

  const teams   = data.teams.map(d => d.team);
  const current = data.teams.map(d => d.owp_current);
  const chalk   = data.teams.map(d => d.owp_proj_chalk);
  const upset   = data.teams.map(d => d.owp_proj_upset);

  Plotly.newPlot(
    document.getElementById('chart'),
    [
      { type: 'bar', x: teams, y: current, name: 'Current OWP',      marker: { color: '#1f77b4' } },
      { type: 'bar', x: teams, y: chalk,   name: 'Projected (Chalk)', marker: { color: '#2ca02c' } },
      { type: 'bar', x: teams, y: upset,   name: 'Projected (Upset)', marker: { color: '#ff7f0e' } }
    ],
    { title: 'SEC OWP — Current vs Projected', barmode: 'group',
      xaxis: { title: 'Team' }, yaxis: { title: 'Opponent Winning % (OWP)', tickformat: '.3f' },
      margin: { l: 60, r: 20, t: 50, b: 60 }
    },
    { displayModeBar: false }
  );

  let html = '<table class="table"><thead><tr>' +
             '<th>Team</th><th>SEC Record</th><th>Current</th><th>Projected (Chalk)</th><th>Projected (Upset)</th>' +
             '</tr></thead><tbody>';
  for (const d of data.teams) {
    html += `<tr><td>${d.team}</td><td>${d.sec_record||''}</td><td>${(d.owp_current||0).toFixed(3)}</td><td>${(d.owp_proj_chalk||0).toFixed(3)}</td><td>${(d.owp_proj_upset||0).toFixed(3)}</td></tr>`;
  }
  html += '</tbody></table>';
  document.getElementById('table').innerHTML = html;
}

setInterval(loadData, 5 * 60 * 1000);
loadData();
